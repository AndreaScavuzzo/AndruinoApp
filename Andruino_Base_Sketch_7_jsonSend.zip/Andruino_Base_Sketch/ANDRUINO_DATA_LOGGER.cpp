
////////////////////////////////////////////////////////////////////////////////////////////////////
//ANDRUINO LIBRARY
//A.Scavuzzo July 2013
//www.andruino.it
////////////////////////////////////////////////////////////////////////////////////////////////////
#include "ANDRUINO_0DEFINES.h"
#include "ANDRUINO_DATA_LOGGER.h"




bool  ANDRUINO_DATA_LOGGER::CheckPin()

{
  if (pin_push_flash < 1000 || pin_push_flash > 9999) {       //PIN not valid
#if DEBUG_SERIAL == 1
    //        Serial.println(F("push pin empty"));
#endif
    push_fail_cnt++;                                        //increment the counter of bad push connection
    return false;
  }
  return true;
}



//push.SendDataLogger(push_user, ARDUINO_NAME, ARDUINO_PASS, 0,0);
bool  ANDRUINO_DATA_LOGGER::SendDataLogger(char *push_usr, char *arduino_name, char *arduino_pass, byte mode, byte module)
{
  if (!CheckPin()) {
    return 0;
  }

#if DEBUG_SERIAL_PUSH == 1
  Serial.println(F("http POST connecting.."));
#endif

//  char *result = 0;

  if (_client.connect("andruino.it", 80)) {    //andruino.it as number
#if DEBUG_SERIAL_PUSH == 1
    Serial.println(F("connected"));
#endif
    _client.print(F("GET /push/rx_post2"));
    _client.print(F("?user="));
    _client.print(push_usr);
    _client.print(F("&pin="));
    _client.print(pin_push_flash);
    _client.print(F("&ardu="));
    _client.print(arduino_name);
    _client.print(F("&pass="));
    _client.print(arduino_pass);
    _client.print(F("&mode="));
    _client.print(mode);
    _client.print(F("&json={"));
    switch (mode) {
      case 0:
        json.JSON_Arduino_ioAnalogs();
        break;
      case 1:
        json.JSON_Arduino_ioDigital();
        break;
      case 2:
        json.JSON_Arduino_Vars();
        break;
      case 3:
        json.JSON_Arduino_System();
        break;
#if ZIGBEE_ENABLE == 1
      case 4:
        json.JSON_Arduino_XBEEio(SystemXBeePins[module].RemoteAddrLSB, module);          //read ZIGBee IO
        break;
#endif
#if NRF24L_ENABLE == 1
      case 5:
        json.JSON_Arduino_NRF24Lio(module);          //read NRF24L IO
        break;
#endif
      default:
        break;
    }
    json.JSON_ClientFlush();          //check the data buffer, send the remain data and clean it

    _client.println(F("} HTTP/1.1"));
    _client.println("Host: andruino.it");
    _client.println(F("Connection: close\r\nContent-Type: application/json"));
    _client.println("User-Agent: Andruino/1.0");
    _client.println();


    int connectLoop = 0;
    int inChar;
    while (_client.connected())
    {
      while (_client.available())
      {
        inChar = _client.read();
        Serial.write(inChar);
        connectLoop = 0;
      }

      delay(1);
      connectLoop++;
      if (connectLoop > 10000)
      {
        Serial.println();
        Serial.println(F("Timeout"));
        _client.stop();
      }
    }

    Serial.println();
    Serial.println(F("disconnecting."));
    _client.stop();



  }
#if DEBUG_SERIAL_PUSH == 1
  else
    Serial.println(F("conn.failed"));
#endif


/*
  if (result) {
    push_success_cnt++;    //increment the counter of good push connection
    return true;
  }
  else {
    push_fail_cnt++;     //increment the counter of bad push connection
    return false;
  }
  
  */

}






/*

JSON_Arduino_ioAnalogs
"ANALOGS":[{"port":"ana0","mode":"ana","val":"2.426"},{"port":"ana1","mode":"ana","val":"2.504"},{"port":"ana2","mode":"ana","val":"2.012"},
{"port":"ana3","mode":"ana","val":"1.939"},{"port":"ana4","mode":"ana","val":"2.152"},{"port":"ana5","mode":"ana","val":"2.431"}]

JSON_Arduino_Vars
"arduino_var":{"VARIABLES":[{"port":"var0","mode":"var","val":"47.500"},{"port":"var1","mode":"var","val":"24.500"},{"port":"var2","mode":"var","val":"9407.000"},
{"port":"var3","mode":"var","val":"3336.000"},{"port":"var4","mode":"var","val":"0.000"},{"port":"var5","mode":"var","val":"0.430"},{"port":"var6","mode":"var","val":"1.293"},
{"port":"var7","mode":"var","val":"0.000"},{"port":"var8","mode":"var","val":"0.000"},{"port":"var9","mode":"var","val":"0.000"},{"port":"var10","mode":"var","val":"0.000"},
{"port":"var11","mode":"var","val":"0.000"},{"port":"var12","mode":"var","val":"0.000"},{"port":"var13","mode":"var","val":"0.000"},{"port":"var14","mode":"var","val":"0.000"},
{"port":"var15","mode":"var","val":"0.000"},{"port":"var16","mode":"var","val":"0.000"},{"port":"var17","mode":"var","val":"0.000"},{"port":"var18","mode":"var","val":"0.000"},
{"port":"var19","mode":"var","val":"0.000"}]}

JSON_Arduino_ioDigital
"DIGITALS":[{"port":"dig3","mode":"pwm","val":"0"},{"port":"dig4","mode":"out","val":"1"},{"port":"dig5","mode":"out","val":"0"},{"port":"dig6","mode":"out","val":"0"},
{"port":"dig7","mode":"out","val":"0"},{"port":"dig8","mode":"out","val":"0"},{"port":"dig9","mode":"in","val":"0"},{"port":"dig10","mode":"out","val":"1"},{"port":"dig11","mode":"out","val":"0"},
{"port":"dig12","mode":"out","val":"0"},{"port":"dig13","mode":"out","val":"0"},{"port":"dig14","mode":"out","val":"0"},{"port":"dig15","mode":"out","val":"0"},
{"port":"dig16","mode":"out","val":"0"},{"port":"dig17","mode":"out","val":"0"},{"port":"dig18","mode":"out","val":"0"},{"port":"dig19","mode":"out","val":"0"},
{"port":"dig20","mode":"out","val":"0"},{"port":"dig21","mode":"out","val":"0"},{"port":"dig22","mode":"in","val":"0"},{"port":"dig23","mode":"in","val":"0"},
{"port":"dig24","mode":"in","val":"0"},{"port":"dig25","mode":"in","val":"0"},{"port":"dig26","mode":"out","val":"0"},{"port":"dig27","mode":"out","val":"0"},
{"port":"dig28","mode":"out","val":"0"},{"port":"dig29","mode":"out","val":"0"}]


#if NRF24L_ENABLE == 1
      for (byte k = 0; k < NRF24LMaxModules; k++) {
        if (SystemNRF24LPins[k].RNF24LAddr != 0) {
          JSON_Arduino_NRF24Lio(k);          //read NRF24L IO
          ClientPrint(",");
        }
      }
#endif
"NRF24L_io_0":{"INFO":["1482","02","3206","88","350","41","1001","2","0"],"DIGITALS":[{"port":"dig3","mode":"in","val":"1"},{"port":"dig4","mode":"in","val":"1"},
{"port":"dig5","mode":"out","val":"0"},{"port":"dig9","mode":"out","val":"0"}],"ANALOGS":[{"port":"ana0","mode":"ana","val":"0.463"},{"port":"ana1","mode":"ana","val":"0.617"},
{"port":"ana2","mode":"ana","val":"1.021"},{"port":"ana3","mode":"ana","val":"0.736"}]},"NRF24L_var_0":{"VARIABLES":[{"port":"var0","mode":"var","val":"0.000"},
{"port":"var1","mode":"var","val":"0.000"},{"port":"var2","mode":"var","val":"0.000"},{"port":"var3","mode":"var","val":"0.000"},{"port":"var4","mode":"var","val":"1482.000"}]}


"NRF24L_io_1":{"INFO":["134","012","2809","600","1877","19","1001","2","1"],"DIGITALS":[{"port":"dig3","mode":"in","val":"1"},{"port":"dig4","mode":"in","val":"1"},{"port":"dig5","mode":"out","val":"0"},
{"port":"dig9","mode":"out","val":"0"}],"ANALOGS":[{"port":"ana0","mode":"ana","val":"0.403"},{"port":"ana1","mode":"ana","val":"0.595"},{"port":"ana2","mode":"ana","val":"0.900"},
{"port":"ana3","mode":"ana","val":"0.697"}]},"NRF24L_var_1":{"VARIABLES":[{"port":"var0","mode":"var","val":"0.000"},{"port":"var1","mode":"var","val":"0.000"},{"port":"var2","mode":"var","val":"0.000"},
{"port":"var3","mode":"var","val":"0.000"},{"port":"var4","mode":"var","val":"133.000"}]}


JSON_Arduino_System
"ardu_tim":[255,255,255,255,255,255,255,255,255,255,255,255],"ardu_sys":{"ardu_date":[3,21,1,22],"ardu_fd2":["andrea.scavu","9411","2.237.242.175","21414"],"ardu_fd":[9407,0,201,1,81,0,7.000,7.000]}



*/




